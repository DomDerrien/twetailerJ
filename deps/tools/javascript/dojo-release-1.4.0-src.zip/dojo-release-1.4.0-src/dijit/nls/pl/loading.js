({
	loadingState: "Ładowanie...",
	errorState: "Niestety, wystąpił błąd"
})
