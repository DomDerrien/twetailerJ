({
	buttonOk: "OK",
	buttonCancel: "Mégse",
	buttonSave: "Mentés",
	itemClose: "Bezárás"
})
