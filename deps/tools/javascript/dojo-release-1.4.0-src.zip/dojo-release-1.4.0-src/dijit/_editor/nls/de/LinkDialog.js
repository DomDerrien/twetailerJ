({
	createLinkTitle: "Linkeigenschaften",
	insertImageTitle: "Grafikeigenschaften",
	url: "URL:",
	text: "Beschreibung:",
	set: "Festlegen"
})
