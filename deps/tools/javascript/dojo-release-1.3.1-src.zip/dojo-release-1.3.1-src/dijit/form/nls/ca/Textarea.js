({
	iframeEditTitle: 'Àrea d\'edició',  // primary title for editable IFRAME, for screen readers
	iframeFocusTitle: 'Marc de l\'àrea d\'edició'  // secondary title for editable IFRAME when focus is on outer container
									 //  to let user know that focus has moved out of editing area and to the 
									 //  parent element of the editing area
})

