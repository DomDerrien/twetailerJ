({
	buttonOk: "D'acord",
	buttonCancel: "Cancel·la",
	buttonSave: "Desa",
	itemClose: "Tanca"
})

