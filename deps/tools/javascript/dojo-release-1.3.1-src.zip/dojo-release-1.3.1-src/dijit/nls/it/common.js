({
	buttonOk: "OK",
	buttonCancel: "Annulla",
	buttonSave: "Salva",
	itemClose: "Chiudi"
})
