({
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "URL:",
	text: "Popis:",
	set: "Nastaviť"
})

