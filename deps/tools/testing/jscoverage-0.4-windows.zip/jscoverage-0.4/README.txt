JSCoverage is a tool that generates code coverage statistics for JavaScript
programs.  For documentation, see the file doc/index.html or the following URL:

  http://siliconforks.com/jscoverage/

Copyright (C) 2007, 2008 siliconforks.com

JSCoverage is free software, distributed under the GNU General Public License. 
The license is included in the file COPYING.

This program contains a copy of SpiderMonkey, Mozilla's JavaScript
implementation.  See the file js/README.html for details.
