function f() {
  return true;
}

function g() {
  return true;
}
