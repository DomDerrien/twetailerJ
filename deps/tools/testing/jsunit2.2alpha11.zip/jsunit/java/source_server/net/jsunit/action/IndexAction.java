package net.jsunit.action;

import com.opensymphony.xwork.Action;

public class IndexAction implements Action {
    public String execute() throws Exception {
        return SUCCESS;
    }
}
