package net.jsunit.action;

import net.jsunit.JsUnitFarmServer;

public interface JsUnitServerAware {
    void setFarmServer(JsUnitFarmServer farmServer);
}
