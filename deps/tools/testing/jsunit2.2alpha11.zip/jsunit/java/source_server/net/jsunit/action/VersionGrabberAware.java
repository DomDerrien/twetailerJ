package net.jsunit.action;

import net.jsunit.version.VersionGrabber;

public interface VersionGrabberAware {
    void setVersionGrabber(VersionGrabber versionGrabber);    
}
