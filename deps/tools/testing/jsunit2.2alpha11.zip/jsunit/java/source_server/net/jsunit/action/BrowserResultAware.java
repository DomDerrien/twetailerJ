package net.jsunit.action;

import net.jsunit.model.BrowserResult;

public interface BrowserResultAware {

    public void setBrowserResult(BrowserResult result);

}
