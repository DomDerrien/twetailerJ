/**
 * 
 */
package net.jsunit;

interface MessageReceiver {
    public void messageReceived(String message);
}