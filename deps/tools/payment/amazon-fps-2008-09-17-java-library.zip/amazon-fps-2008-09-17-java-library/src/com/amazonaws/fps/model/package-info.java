@javax.xml.bind.annotation.XmlSchema(namespace = "http://fps.amazonaws.com/doc/2008-09-17/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amazonaws.fps.model;
